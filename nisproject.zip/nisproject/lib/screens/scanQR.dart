import 'package:flutter/material.dart';

class scanQR extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ScanQR'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Expanded(
              flex: 3,
              child: Container(
                
                decoration: BoxDecoration(
                    border: Border.all(style: BorderStyle.solid)),
                child: Image.network(
                    'https://static.vecteezy.com/system/resources/previews/000/402/969/non_2x/illustration-of-online-payment-with-matrix-barcode-vector.jpg'),
              ),
            ),
            Expanded(child: Text('Scanned Data')),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, 'enterD');
              },
              child: Text("Enter Details", style: TextStyle(color: Colors.white),),
              disabledColor: Colors.blueGrey,
              color: Colors.blueAccent,
            ),
          ],
        ),
      ),
    );
  }
}
