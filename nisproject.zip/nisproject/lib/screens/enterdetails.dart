import 'package:flutter/material.dart';

class enterDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Enter Details'),
        ),
        body: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    ("Enter your username and password"),
                    style: TextStyle(
                        fontFamily: 'OpenSansCondensed', fontSize: 20),
                  )),
              SizedBox(height: 60),
              Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                    shape: BoxShape.rectangle, border: Border.all(width: 1)),
                child: Column(
                  children: <Widget>[
                    TextField(
                      decoration: InputDecoration(
                        fillColor: Colors.green,
                        icon: Icon(Icons.person),
                      ),
                    ),
                    TextField(
                      obscureText: true,
                      decoration: InputDecoration(icon: Icon(Icons.lock_open)),
                    )
                  ],
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: RaisedButton(
                    color: Color(0xff00204a),
                    textColor: Colors.white,
                    child: Text("Done"),
                    onPressed: () {
                      Navigator.pushNamed(context, '/');
                    }),
              ),
            ],
          ),
        ));
  }
}
