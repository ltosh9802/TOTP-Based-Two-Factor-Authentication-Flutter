import 'package:flutter/material.dart';

class generatePIN extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Generate PIN'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: Center(
                  child: Text(
                    ("PIN:\n123456"),
                    style: TextStyle(fontFamily: 'Monstserrat', fontSize: 50),
                  ),
                ),
              ),
              RaisedButton(
                  color: Color(0xff00204a),
                  textColor: Colors.white,
                  child: Text("Done"),
                  onPressed: () {
                    Navigator.pushNamed(context, '/');
                  }),
            ],
          ),
        ));
  }
}
